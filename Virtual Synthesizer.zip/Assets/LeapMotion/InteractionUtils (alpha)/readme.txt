Interaction Utilities (alpha)

NOTE: These assets are currently in alpha and many features are incompatible.
If you find any bugs, please email them to mtytel@leapmotion.com.

The Interaction Utilities allow more complex manipulation of objects. You can
grab objects and rotate them in several ways using the active hand or by using
a second hand. You can scale an object by grabbing it with two hands and
pulling apart or pushing together.

There is more documentation to come.
