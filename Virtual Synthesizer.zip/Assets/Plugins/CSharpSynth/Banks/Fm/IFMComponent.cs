﻿namespace CSharpSynth.Banks.Fm
{
    public interface IFMComponent
    {
        double doProcess(double value);
    }
}
